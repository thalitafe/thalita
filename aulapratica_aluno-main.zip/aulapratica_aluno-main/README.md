# aulapratica_aluno
 Exercícios práticos Alunos Cetam LPII - PHP
