<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="stylesheet" href="estilo.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ex 01</title>
</head>
<body>
<!--
Crie um programa que leia o nome e o salário de um funcionário,
mostrando no final uma mensagem. Ex:
Nome do Funcionário: Maria do Carmo
Salário: R$1.850,45
O funcionário Maria do Carmo tem um salário de R$1.850,45 em (data de hoje).
-->
<div>




</div>
</body>
</html>